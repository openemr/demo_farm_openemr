#!/bin/bash
PID=$(pgrep -f "openvpn vpnclient.ovpn")
kill -9 $PID
echo "VPN Connection stopped"
