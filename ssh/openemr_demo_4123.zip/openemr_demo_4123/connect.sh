#!/bin/bash
DIR=`echo $(dirname $(readlink -f $0))`
cd $DIR
openvpn vpnclient.ovpn &
